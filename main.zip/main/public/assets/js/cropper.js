(function($) {
  'use strict';
  $('#cropperExample').cropper({
    aspectRatio: 16 / 9
  });
})(jQuery);