@extends('admin.partials.template')

@section('content')
    
@endsection