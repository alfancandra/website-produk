

<?php $__env->startSection('content'); ?>
<div class="container-xxl py-5">
    <div class="container">
        <div class="text-center mx-auto pb-4 wow fadeInUp" data-wow-delay="0.1s" style="max-width: 500px;">
            <p class="section-title bg-white text-center text-primary px-3">Info</p>
            <h1 class="mb-5 text-primary"></h1>
        </div>
        <div class="row">
            <div class="col text-center">
                <h1><?php echo e($data->nama); ?></h1>
                <br>
                <a href="<?php echo e($data->alamat_link); ?>" target="_blank">
                    <span><?php echo e($data->alamat); ?></span>
                </a>
            </div>
            <div class="col">
                <?php echo e($data->deskripsi); ?>

                <br><br>
                <a href="https://wa.me/<?php echo e($data->whatsapp); ?>" target="_blank">
                    <img src="<?php echo e(asset('assets/img/wa.png')); ?>" style="margin-right: 20px" width="50px"/> <?php echo e($data->whatsapp); ?>

                </a>
                <br><br>
                <a href="https://instagram.com/<?php echo e($data->instagram); ?>" target="_blank">
                    <img src="<?php echo e(asset('assets/img/ig.png')); ?>" style="margin-right: 20px" width="50px"/> <?php echo e($data->instagram); ?>

                </a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('partials.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\website-produk\main\resources\views/info.blade.php ENDPATH**/ ?>