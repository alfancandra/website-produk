

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <?php if($message = Session::get('success')): ?>
                        <div id="alert" class="alert alert-success alert-block mb-3">
                            <?php echo e($message); ?>

                        </div>
                    <?php endif; ?>
                    <?php if($message = Session::get('error')): ?>
                        <div id="alert" class="alert alert-danger alert-block mb-3">
                            <?php echo e($message); ?>

                        </div>
                    <?php endif; ?>
                    <h4 class="card-title">Data Pemesanan</h4>
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th style="width: 10%">
                                        No
                                    </th>
                                    <th>
                                        Nama Produk
                                    </th>
                                    <th>
                                        Qty
                                    </th>
                                    <th>
                                        Nama Pemesan
                                    </th>
                                    <th>
                                        Tanggal
                                    </th>
                                    <th>
                                        Status
                                    </th>
                                    <th>
                                        Action
                                    </th>
                                    <th>
                                        Set Status
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($key+1); ?></td>
                                        <td><?php echo e($item->nama); ?></td>
                                        <td><?php echo e($item->qty); ?></td>
                                        <td><?php echo e($item->nama_pemesan); ?></td>
                                        <td><?php echo e($item->created_at); ?></td>
                                        <td><?php echo e($item->status); ?></td>
                                        <td><a href="<?php echo e(route('adm.pemesanan.show',$item->id)); ?>" class="btn btn-primary">Detail</a>
                                        </td>
                                        <td> 
                                            <?php if($item->status == 'PENDING'): ?>
                                            <a href="<?php echo e(route('adm.pemesanan.set',['id'=>$item->id, 'status'=>'DIPROSES'])); ?>" class="btn btn-warning">DIPROSES</a>
                                            <a href="<?php echo e(route('adm.pemesanan.set',['id'=>$item->id, 'status'=>'CANCEL'])); ?>" class="btn btn-danger">CANCEL</a>
                                            <?php elseif($item->status == 'DIPROSES'): ?>
                                            <a href="<?php echo e(route('adm.pemesanan.set',['id'=>$item->id, 'status'=>'DIKIRIM'])); ?>" class="btn btn-primary">DIKIRIM</a>
                                            <a href="<?php echo e(route('adm.pemesanan.set',['id'=>$item->id, 'status'=>'CANCEL'])); ?>" class="btn btn-danger">CANCEL</a>
                                            <?php elseif($item->status == 'DIKIRIM'): ?>
                                            <a href="<?php echo e(route('adm.pemesanan.set',['id'=>$item->id, 'status'=>'SUKSES'])); ?>" class="btn btn-success">SUKSES</a>
                                            <?php else: ?> 
                                            -
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.partials.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\website-produk\main\resources\views/admin/pemesanan/index.blade.php ENDPATH**/ ?>