

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <?php if($message = Session::get('success')): ?>
                        <div id="alert" class="alert alert-success alert-block mb-3">
                            <?php echo e($message); ?>

                        </div>
                    <?php endif; ?>
                    <?php if($message = Session::get('error')): ?>
                        <div id="alert" class="alert alert-danger alert-block mb-3">
                            <?php echo e($message); ?>

                        </div>
                    <?php endif; ?>
                    <h4 class="card-title">Data User</h4>
                    <p class="card-description">
                        <a href="<?php echo e(route('adm.user.create')); ?>" class="btn btn-primary">Tambah User</a>
                    </p>
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th style="width: 10%">
                                        No
                                    </th>
                                    <th>
                                        Name
                                    </th>
                                    <th>
                                        Username
                                    </th>
                                    <th>
                                        Role
                                    </th>
                                    <th>
                                        Created At
                                    </th>
                                    <th>
                                        Action
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($key+1); ?></td>
                                        <td><?php echo e($item->name); ?></td>
                                        <td><?php echo e($item->username); ?></td>
                                        <td><?php echo e($item->role); ?></td>
                                        <td><?php echo e($item->created_at); ?></td>
                                        <td><a href="<?php echo e(route('adm.user.edit',$item->id)); ?>" class="btn btn-success">Edit</a>
                                            <a href="<?php echo e(route('adm.user.hapus',$item->id)); ?>" onclick="return confirm('Are you sure you want to delete this item?');" class="btn btn-danger">Hapus</a></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.partials.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\website-produk\main\resources\views/admin/user/index.blade.php ENDPATH**/ ?>