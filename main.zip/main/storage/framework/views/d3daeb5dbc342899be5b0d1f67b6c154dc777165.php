

<?php $__env->startSection('content'); ?>
<div class="container-xxl py-5">
    <div class="container">
        <?php if(isset($_GET['cari'])): ?>
        <div class="text-center mx-auto pb-4 wow fadeInUp" data-wow-delay="0.1s" style="max-width: 500px;">
            <p class="section-title bg-white text-center text-primary px-3">Hasil Pencarian</p>
            <h1 class="mb-5 text-primary"><?php echo e($_GET['cari']); ?></h1>
        </div>
        <?php else: ?>
        <div class="text-center mx-auto pb-4 wow fadeInUp" data-wow-delay="0.1s" style="max-width: 500px;">
            <p class="section-title bg-white text-center text-primary px-3">Produk Kami</p>
            <h1 class="mb-5 text-primary">Produk Kami yang Telah Tersedia di Jajanku</h1>
        </div>
        <?php endif; ?>
        <div class="row gy-5 gx-4">

            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-3 col-md-6 pt-5 wow fadeInUp" data-wow-delay="0.1s">
                <div class="service-item d-flex h-100">
                    <div class="service-img">
                        <img class="img-fluid" src="<?php echo e(asset('images/'.$item->foto)); ?>" alt="">
                    </div>
                    <div class="service-text p-5 pt-0">
                        <div class="service-icon">
                            <img class="img-fluid rounded-circle" src="<?php echo e(asset('images/'.$item->foto)); ?>" alt="">
                        </div>
                        <h5 class="mb-3"><?php echo e($item->nama); ?></h4>
                        <p class="mb-4"><?php echo e($item->deskripsi); ?></p>
                        <a class="btn btn-square rounded-circle" href="<?php echo e(route('produk.detail',$item->id)); ?>"><i class="bi bi-chevron-double-right"></i></a>
                    </div>
                </div>
            </div>    
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('partials.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\website-produk\main\resources\views/produk.blade.php ENDPATH**/ ?>