

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">Edit Data Produk</h4>
                    <p class="card-description">
                        Form ini digunakan untuk mengedit Produk
                    </p>
                    <form action="<?php echo e(route('adm.produk.update',$data->id)); ?>" method="post" class="forms-sample" enctype="multipart/form-data">
                    <?php echo method_field('put'); ?>
                    <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="exampleInputName1">Nama produk</label>
                            <input type="text" value="<?php echo e($data->nama); ?>" name="nama" class="form-control" id="exampleInputName1" placeholder="Produk">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail3">Harga Produk</label>
                            <input type="number" value="<?php echo e($data->harga); ?>" name="harga" class="form-control" id="exampleInputEmail3" placeholder="Harga">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword4">Deskripsi Produk</label>
                            <input type="text" value="<?php echo e($data->deskripsi); ?>" name="deskripsi" class="form-control" id="exampleInputPassword4" placeholder="Deskripsi">
                        </div>
                        <div class="form-group">
                            <img src="<?php echo e(asset('images/'.$data->foto)); ?>" width="150px"/>
                        </div>
                        <span class="text-warning">Upload Foto untuk mengganti Foto Produk</span>
                        <div class="form-group">
                            <label>File upload</label>
                            <input type="file" name="img" class="file-upload-default">
                            <div class="input-group col-xs-12">
                                <input type="text" class="form-control file-upload-info" disabled=""
                                    placeholder="Upload Image">
                                <span class="input-group-append">
                                    <button class="file-upload-browse btn btn-primary" type="button">Upload</button>
                                </span>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary me-2">Submit</button>
                        <a class="btn btn-light" href="<?php echo e(route('adm.produk.index')); ?>">Cancel</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script src="<?php echo e(asset('assets/js/file-upload.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.partials.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\website-produk\main\resources\views/admin/produk/edit.blade.php ENDPATH**/ ?>