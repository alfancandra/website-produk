

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">Data Pemesanan</h4>
                    <div class="form-group">
                        <label for="exampleInputName1">Nama produk</label>
                        <input type="text" value="<?php echo e($data->nama_produk); ?>" readonly class="form-control" id="exampleInputName1" placeholder="Produk">
                    </div>
                    <div class="form-group">
                        <label for="exampleInputEmail3">Harga Produk</label>
                        <input type="number" value="<?php echo e($data->harga); ?>" readonly class="form-control" id="exampleInputEmail3" placeholder="Harga">
                    </div>
                    <div class="form-group">
                        <label for="exampleInputPassword4">Quantity</label>
                        <input type="text" value="<?php echo e($data->qty); ?>" readonly class="form-control" id="exampleInputPassword4" placeholder="Deskripsi">
                    </div>
                    <div class="form-group">
                        <label for="exampleInputPassword4">Nama Lengkap</label>
                        <input type="text" value="<?php echo e($data->nama); ?>" readonly class="form-control" id="exampleInputPassword4" placeholder="Deskripsi">
                    </div>
                    <div class="form-group">
                        <label for="exampleInputPassword4">Alamat Lengkap</label>
                        <input type="text" value="<?php echo e($data->alamat); ?>" readonly class="form-control" id="exampleInputPassword4" placeholder="Deskripsi">
                    </div>
                    <div class="form-group">
                        <label for="exampleInputPassword4">Nomor Handphone</label>
                        <input type="text" value="<?php echo e($data->hp); ?>" readonly class="form-control" id="exampleInputPassword4" placeholder="Deskripsi">
                    </div>
                    <div class="form-group">
                        <label for="exampleInputPassword4">Pembayaran</label>
                        <input type="text" value="<?php echo e($data->pembayaran); ?>" readonly class="form-control" id="exampleInputPassword4" placeholder="Deskripsi">
                    </div>
                    <div class="form-group">
                        <label for="exampleInputPassword4">Tanggal</label>
                        <input type="text" value="<?php echo e($data->created_at); ?>" readonly class="form-control" id="exampleInputPassword4" placeholder="Deskripsi">
                    </div>
                    <div class="form-group">
                        <label for="exampleInputPassword4">Status</label>
                        <input type="text" value="<?php echo e($data->status); ?>" readonly class="form-control" id="exampleInputPassword4" placeholder="Deskripsi">
                    </div>
                    <a class="btn btn-light" href="<?php echo e(route('adm.pemesanan.index')); ?>">Back</a>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script src="<?php echo e(asset('assets/js/file-upload.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.partials.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\website-produk\main\resources\views/admin/pemesanan/show.blade.php ENDPATH**/ ?>